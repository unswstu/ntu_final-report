var http = require("http");
var url = require('url');
var fs = require('fs');

var app = require("http").createServer()


var io = require('socket.io')(app); 

var pathh = require('path');

//var io = require('socket.io')(port);
//var io = require('socket.io')(server);

var server = http.createServer(function(request, response) {
  console.log('Connection');
  
  var path = url.parse(request.url).pathname;

  switch (path) {
    case '/':
      response.writeHead(200, {'Content-Type': 'text/html'});
      response.write('Hello JIA.');
      response.end();
      break;
    case '/socket.html':
      fs.readFile(__dirname + path, function(error, data) {
        if (error){
          response.writeHead(404);
          response.write("try another path");
        } else {
          response.writeHead(200, {"Content-Type": "text/html"});
          response.write(data, "utf8");
        }
        response.end();
      });
      break;
    default:
      response.writeHead(404);
      response.write("try another path too");
      response.end();
      break;
  }
});

server.listen(8001);

io.listen(server); 



var serv_io = io.listen(server);

//serv_io.sockets.on('connection', function(socket) {
    //socket.emit('message', {'message': 'hello jia'});
//});

//serv_io.sockets.on('connection', function(socket) {
   
    //setInterval(function() {
     // socket.emit('date', {'date': new Date()});
    //}, 1000);
 // });

 //<script>
 //var socket = io.connect();

 //socket.on('date', function(data) {
  // $('#date').text(data.date);
 //});
//</script>
//<div id="date"></div>




 //io.on('connection', function(socket){
    serv_io.sockets.on('connection', function(socket){


     fs.readFile('image.png', function(err, data){
      socket.emit('imageConversionByClient', { image: true, buffer: data });
      socket.emit('imageConversionByServer', "data:image/png;base64,"+ data.toString("base64"));
      });
    });



    serv_io.sockets.on('connection', function(socket) {
   
    setInterval(function() {
      socket.emit('date', {'date': new Date()});
    }, 1000);
    });



    var fs = require('fs'),
    bite_size = 256,
    readbytes = 0,
    file;

fs.open('test-read-write.txt', 'r', function(err, fd) { file = fd; readsome(); });

function readsome() {
    var stats = fs.fstatSync(file); 
    if(stats.size<readbytes+1) {
        console.log('sleep');
        setTimeout(readsome, 3000);
    }
    else {
        fs.read(file, new Buffer(bite_size), 0, bite_size, readbytes, processsome);
    }
}

function processsome(err, bytecount, buff) {
    console.log('Read', bytecount, ' process it now.');

   
        console.log(buff.toString('utf-8', 0, bytecount));

        serv_io.sockets.on('connection', function(socket) {
            setInterval(function() {
            socket.emit('word', {'word': (buff.toString('utf-8', 0, bytecount))});
            }, 1000);
           });

       
    
    readbytes+=bytecount;
    process.nextTick(readsome);
}

var express = require('express'), 
    app = express(), 
    http = require('http'), 
    socketIO = require('socket.io'), 
    fs = require('fs'), 
    path = require('path'), 
    server, 
    io; 

app.get('/', function (req, res) { 
 res.sendFile(__dirname + '/socket.html'); 
});  

server = http.Server(app); 
server.listen(5000);  
io = socketIO(server);  



io.on('connection', function(socket) {
   
    setInterval(function() {
      socket.emit('date', {'date': new Date()});
    }, 1000);

    socket.on('client_data', function(data) {
        process.stdout.write(data.letter);
      });


    });


io.on('connection', function (socket) { 
   
    console.log('connect');
    //var interval = setInterval(function(){

    var readStream = fs.createReadStream(path.resolve(__dirname, './output.jpg'), { encoding: 'binary' }), chunks = [], vari=0;

    
  
    //setInterval(function(){
       // var readStream = fs.createReadStream(path.resolve(__dirname, './ntu.jpg'), { encoding: 'binary'     }), chunks = [];
       // readStream.on('data', function (chunk) { 
        //chunks.push(chunk); 
        //socket.emit('img-chunk', chunk)},5000);
    //});




   // });

    readStream.on('readable', function () { 
        console.log('Image loading');     
        console.log(`readable: ${readStream.read()}`);
    });  

    readStream.on('data', function (chunk) { 
        
        chunks.push(chunk); 
        vari=vari+5000;
       
      var interval = setInterval(function(){

       //setTimeout(function(){
     


        socket.emit('img-chunk', chunk);  

      },5000);

       
       
        
    });  

    readStream.on('end', function () { 
    	console.log('Image loaded');     
    }); 

//},5000);


   
});

//var io = require('socket.io').listen(80);
//var ss = require('socket.io-stream');
//var path = require('path');

//io.of('/user').on('connection', function(socket) {
  //ss(socket).on('profile-image', function(stream, data) {
    //var filename = path.basename(data.name);
    //stream.pipe(fs.createWriteStream(filename));
  //});
//});
    













   
 
